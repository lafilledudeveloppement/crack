#include <stdio.h>
#include <cs50.h>

int main(void)
{
    int r= get_int("r:");
    int t=get_int("t:");
    int y=add(r,t);

    printf("the sum is %i",y);
}
int add(int r,int t)
{
    return(r+t);
}