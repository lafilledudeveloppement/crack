# include <stdio.h>
# include <cs50.h>

int add(int a,int b);
int main (void)
{
    int a=get_int("a:");
    int b=get_int("b:");
    int c=add(a,b);

    printf("%d\n",c);
}
int add(int a,int b)
{
    return a+b;
}