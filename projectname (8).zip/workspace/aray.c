# include <stdio.h>
# include <cs50.h>

itn main(int argc, stringargv [])
{
   // parcourir le nombre dargument
    for(int i=0; i<argc; i++)
    {
        for (int )
    }
}