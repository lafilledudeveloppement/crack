# include <stdio.h>
# include <cs50.h>
#include <string.h>

int main(int argc,string argv[])
{
    //1er boucle for parcours les chaine de caractere
    for(int i=0; i<argc;i++)
    {
        //2em boucle for parcours les caractere de la chaine
        for (int j=0,n= strlen(argv[1]);j<n;j++)
        {
          printf("%c\n",argv[i][j]);
        }
        printf("\n");
    }
}