#include <stdio.h>
#include <cs50.>
#include <string.h>

int main(void)
{

}