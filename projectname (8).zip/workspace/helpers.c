# include <stdio.h>
# include <cs50.h>
# include <string.h>
# include <math.h>
# include <herpers.h>

int duration(string fraction)
{
    int n = strlen(fraction);
    int numerador = atoi(&fraction[0]);
    int denominador = atoi(&fraction[n-1]);
    return ((8 / denominador) *numerador);
}
int frequency(string note)
{
    int octave = note[strlen(note)-1]-0;
    int dif = octave 4
    int f;
    if(dif <0)
    {
        f = 440 / 2 ^ (dif);
    }
    else
    {
        f = 440 * ^ (dif);
    }
    double freq = 440.0;
    if (note[0]== 'B')
    {
        freq *= (pow(2.0,(2.0/ 12.0)));
    }
    else if (note[0]=='C')
    {
        freq /= (pow(2.0, (9.0 / 12.0)));
    }
    else if (note[0]== 'D')
    {
        freq /= (pow(2.0, (7.0/ 12.0)));
    }
    else if (note[0]== 'E')
    {
        freq /= (pow(2.0,(5.0 / 12.0)));
    }
    else if (note[0] == 'F')
    {
        freq /= (pow(2.0, (4.0 / 12.0)));
    }
    else if (note[0] =='G')
    {
        freq /= (pow(2.0,(2.0 / 12)));
    }

    if (note[1]== '#')
    {
        freq *= (pow(2.0, (1 / 12)));
    }
    else if (note[1]== 'b')
    {
        freq /=(pow(2.0, (1 / 12)));
        return round(freq) + f;
    }
    bool is_rest(string s)
    if (s == NULL)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}