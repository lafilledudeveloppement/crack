#include<stdio.h>
#include<cs50.h>
#include<string.h>
typedef sstruct
{
    int Id;
    char* sex;
    char* name;
    int quizone;
    int finalscore;
}
   students;

}
#include "struct.h"

 int main(void)

 {
     student students [20];
     for(int i=0 ; i<20 ;i++)
     {
         students[i].Id=get_int("your Id:"):
         student[i].sex=get_string("your sex:")student ;
         student[i].name=get_string("your name:");
         student[i].quizone=get_int("your quizone:");
         stdent[i].finalscore=get_int("your finalscore:");
     }
     printf("%d , %s , %s ,%d , %d" , students[i].Id , students[i].sex , students[i].name , students[i].quizone , students[i].finalscore );
 }