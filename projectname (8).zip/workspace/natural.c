# include <stdio.h>
# include <cs50.h>

int main(void)
{
    int number=100;
    for(int i=1;i<number;i++)
    {
        printf("%i\n",i);
    }
}