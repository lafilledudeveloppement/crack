# include <stdio.h>
# include <cs50.h>
int main(void)

{
    string name=get_string("name:");
    for(int i=1; i<20;i++)
    {
        printf("%s\n",name);
    }
}