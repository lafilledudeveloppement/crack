# include <stdio.h>

int main(void)
{
    int a;
    int b;
    int p;
    a=&b;
    *p=b
}