# include <stdio.h>
# include <cs50.h>
# include <ctype.h>
# include <string.h>
//pour mettre le nom en majuscule
int main(void)
{
    string name=get_string("name:");

    for(int i=0; i<strlen(name); i++)
    {
        printf("%c", toupper(name[i]));
    }
}