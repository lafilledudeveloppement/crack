# include <stdio.h>
# include <cs50.h>
# include <string.h>
# include "struct.h"

int main(void)
{
int n=get_int ("n:");
student students [n];

for(int i=0; i<n; i++)
{
    students[i].name=get_string("name:");
    students[i].dorm=get_string("dorm:");
}
FILE *file=fopen("students.csv","w");

if(file)
{
    for(int i=0; i<n; i++)
    {
        fprintf(file,"%s,%s\n",students[i].name,students[i].dorm);
    }
    fclose(file);
}
}