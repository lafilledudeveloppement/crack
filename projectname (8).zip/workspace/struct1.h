typedef struct
{
    int Id;
    char *name;
    char *sex;
    int quiz;
    int midscore;
    int finalscore;
    int totalscore;

}
student;