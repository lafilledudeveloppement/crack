# include <stdio.h>
# include <cs50.h>
# include <string.h>
# include "struct.h"

 int main(void)
{
    student students[20];

    for(int i=0; i<n; i++)
    {
        students[i].Id = get_int("id:");
        students[i].name = get_string("name:");
        students[i].sex = get_string("sex:");
        students[i].quiz = get_int("quiz:");
        students[i].midscore = get_int("midscore:");
        students[i].finalscore = get_int("finalscore:");
        students[i].totalscore = get_int("totalscore");

    }
    printf("%d, %s, %s, %d, %d, %d, %d\n", students[i].Id, students[i].name, students[i].sex, students[i].quiz, students[i].midscore, students[i].finalscore, students[i].totalscore);
}