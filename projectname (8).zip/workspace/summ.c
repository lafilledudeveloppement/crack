# include <stdio.h>
# include <cs50.h>
int main(void)

{
    int array[10];
    int sum;
    int product;
    int i;
    for (int i=0; i<10; i++)
    {
        printf("enter array[%d]:",i);
        scanf("%d",& array[i]);
    }
    sum=0;
    product=1;
    for(int i=0; i<10; i++)
    {
        sum=sum+array[i];
        product=product*array[i];
    }
    {
        printf("sum of array is %d\n",sum);
        printf("product of array is %d\n",product);
    }
}