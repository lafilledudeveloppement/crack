# include <stdio.h>
# include <cs50.h>
# include <ctype.h>

int main(void)
{
    string name=get_string("enter your name:");

    if(isupper(name[0]))
    {
        printf("your name is valid\n");
    }

    else
    {
        printf("your name is valid\n");
    }
}